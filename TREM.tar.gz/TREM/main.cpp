#include <iostream>
#include "controller.h"
using namespace std;



int main(){
    Controller c;
    c.commandLine();
    return 0;
}

